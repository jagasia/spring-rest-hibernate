package spring.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Component;

@Component("vdao")
public class VehicleDao {
	private static Session getSession() {
		Configuration config = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Vehicle.class);
		SessionFactory sessoinFactory = config.buildSessionFactory();
		Session session = sessoinFactory.openSession();
		return session;
	}
	public int create(Vehicle vehicle)
	{
		Session session = getSession();
		Transaction tran = session.beginTransaction();
		int id = (int) session.save(vehicle);
		tran.commit();
		session.close();
		return id;
	}
	public List<Vehicle> read()
	{
		Session session = getSession();
		List<Vehicle> vehicles = session.createCriteria(Vehicle.class).list();
		session.close();
		return vehicles;
	}
	public Vehicle read(int id)
	{
		Session session = getSession();
		Vehicle vehicle = (Vehicle) session.get(Vehicle.class, id);
		session.close();
		return vehicle;
	}
	public Vehicle update(Vehicle vehicle)
	{
		Session session = getSession();
		Transaction tran = session.beginTransaction();
		Vehicle vehicle1=(Vehicle) session.merge(vehicle);
		tran.commit();
		session.close();
		return vehicle1;
	}
	public void delete(Vehicle vehicle)
	{
		Session session = getSession();
		Transaction tran = session.beginTransaction();
		session.delete(vehicle);
		tran.commit();
		session.close();
	}


	public static void main(String[] args) {
		VehicleDao vdao=new VehicleDao();
		Vehicle vehicle = vdao.read(149);
		vdao.delete(vehicle);
		System.out.println("Done");
	}
}
