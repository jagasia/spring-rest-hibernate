package spring.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import spring.model.Vehicle;
import spring.model.VehicleDao;

@RestController
public class MyController {
	@Autowired
	VehicleDao vdao;
	@GetMapping("/")
	public String hello()
	{
		return "hi ";
	}
	
	@GetMapping("/vehicles")
	public List<Vehicle> getAllVehicles()
	{
		return vdao.read();
	}
	
	@GetMapping("/vehicles/{id}")
	public Vehicle findVehicleById(@PathVariable("id") int id)
	{
		return vdao.read(id);
	}
	
	@PostMapping("/vehicles")
	public int addVehicle(@RequestBody Vehicle vehicle)
	{
		return vdao.create(vehicle);
	}
	
	@PutMapping("/vehicles")
	public Vehicle updateVehicle(@RequestBody Vehicle vehicle)
	{
		return vdao.update(vehicle);
	}
	
	@DeleteMapping("/vehicles")
	public void deleteVehicle(@RequestBody Vehicle vehicle)
	{
		System.out.println(vehicle);
		vdao.delete(vehicle);
	}
}
